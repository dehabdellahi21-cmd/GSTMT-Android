package mr.gstmt.app

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth

/**
 * Écran de connexion par e-mail/mot de passe, à intégrer explicitement dans la navigation.
 * Il ne crée pas de comptes : ceux-ci doivent être créés par l'administration via un canal sécurisé.
 * Ne pas considérer une connexion réussie comme une autorisation d'accès aux données :
 * les rôles et permissions doivent être vérifiés côté serveur/Firestore.
 */
@Composable
fun FirebaseSignInScreen(
    onSignedIn: (uid: String, email: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val firebaseConfigured = remember { isFirebaseConfigured(context) }

    Column(
        modifier = modifier.fillMaxWidth().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Connexion — Groupe Scolaire TMT", style = MaterialTheme.typography.titleLarge)
        if (!firebaseConfigured) {
            Text("Firebase n’est pas configuré. Ajoutez le vrai fichier google-services.json, puis synchronisez Gradle.")
        } else {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it.trim(); message = null },
                label = { Text("Adresse e-mail") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = password,
                onValueChange = { password = it; message = null },
                label = { Text("Mot de passe") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                enabled = !busy && email.contains("@") && password.isNotBlank(),
                onClick = {
                    busy = true
                    message = null
                    FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            busy = false
                            val user = task.result?.user
                            if (task.isSuccessful && user != null) {
                                onSignedIn(user.uid, user.email)
                            } else {
                                // Message volontairement générique : ne pas révéler si un compte existe.
                                message = "Connexion impossible. Vérifiez vos informations ou contactez l’administration."
                            }
                        }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Se connecter") }
            Button(
                enabled = !busy && email.contains("@"),
                onClick = {
                    busy = true
                    message = null
                    FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                        .addOnCompleteListener { task ->
                            busy = false
                            message = if (task.isSuccessful)
                                "Si cette adresse est enregistrée, un e-mail de réinitialisation sera envoyé."
                            else "Demande impossible pour le moment. Contactez l’administration."
                        },
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Mot de passe oublié") }
            if (busy) CircularProgressIndicator()
            message?.let { Spacer(Modifier.height(4.dp)); Text(it) }
        }
    }
}

private fun isFirebaseConfigured(context: Context): Boolean =
    try { FirebaseApp.getApps(context).isNotEmpty() } catch (_: IllegalStateException) { false }
