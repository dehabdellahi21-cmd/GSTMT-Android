package mr.gstmt.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF12304A)
private val Teal = Color(0xFF0F766E)
private val Gold = Color(0xFFE2B45B)
private val Canvas = Color(0xFFF4F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SchoolApp() }
    }
}

private enum class Page { HOME, GRADES, ATTENDANCE, HOMEWORK, NEWS }

@Composable
private fun SchoolApp() {
    var arabic by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf(Page.HOME) }
    val rtl = arabic
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy, secondary = Teal, tertiary = Gold,
            background = Canvas, surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val items = listOf(
                        Triple(Page.HOME, if (rtl) "الرئيسية" else "Accueil", Icons.Default.Home),
                        Triple(Page.GRADES, if (rtl) "النتائج" else "Notes", Icons.Default.School),
                        Triple(Page.ATTENDANCE, if (rtl) "الحضور" else "Présences", Icons.Default.EventAvailable),
                        Triple(Page.HOMEWORK, if (rtl) "الواجبات" else "Devoirs", Icons.Default.MenuBook),
                        Triple(Page.NEWS, if (rtl) "الأخبار" else "Infos", Icons.Default.Campaign)
                    )
                    items.forEach { (target, label, icon) ->
                        NavigationBarItem(
                            selected = page == target,
                            onClick = { page = target },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth()
                            .background(Navy, RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                            .padding(horizontal = 22.dp, vertical = 22.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.gstmt_logo),
                                contentDescription = if (rtl) "شعار المدرسة" else "Logo provisoire de l’établissement",
                                modifier = Modifier.size(76.dp).padding(end = 12.dp)
                            )
                            Column(Modifier.weight(1f)) {
                                Text("GSTMT", color = Gold, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                Text(
                                    if (rtl) "مجموعة ثيرنو مونتاغا تال المدرسية" else "Groupe Scolaire\nThierno Mountaga Tall",
                                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp,
                                    lineHeight = 27.sp
                                )
                            }
                            OutlinedButton(
                                onClick = { arabic = !arabic },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                            ) { Text(if (rtl) "FR" else "عربي") }
                        }
                        Spacer(Modifier.height(20.dp))
                        Text(if (rtl) "بوابتكم المدرسية الرقمية" else "Votre portail scolaire numérique",
                            color = Color(0xFFD7E4EF), fontSize = 14.sp)
                        Spacer(Modifier.height(15.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard(if (rtl) "الفصل" else "Année scolaire", "2026–2027", Modifier.weight(1f))
                            StatCard(if (rtl) "المجتمع" else "Communauté", if (rtl) "المدرسة" else "École", Modifier.weight(1f))
                        }
                    }
                }
                item { Spacer(Modifier.height(18.dp)) }
                item {
                    Column(Modifier.padding(horizontal = 18.dp)) {
                        Text(
                            when (page) {
                                Page.HOME -> if (rtl) "مرحباً بكم" else "Bienvenue"
                                Page.GRADES -> if (rtl) "النتائج الدراسية" else "Résultats scolaires"
                                Page.ATTENDANCE -> if (rtl) "الحضور والغياب" else "Présences et absences"
                                Page.HOMEWORK -> if (rtl) "الواجبات" else "Devoirs"
                                Page.NEWS -> if (rtl) "إعلانات المدرسة" else "Annonces de l’école"
                            },
                            color = Navy, fontWeight = FontWeight.Bold, fontSize = 21.sp
                        )
                        Spacer(Modifier.height(12.dp))
                        when (page) {
                            Page.HOME -> {
                                InfoCard("📢", if (rtl) "إعلان المدرسة" else "Annonce de l’établissement",
                                    if (rtl) "سيتم نشر الإعلانات الرسمية هنا." else "Les annonces officielles de l’établissement seront publiées ici.")
                                Spacer(Modifier.height(12.dp))
                                Text(if (rtl) "الخدمات" else "Services", color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    ServiceTile("📘", if (rtl) "النتائج" else "Notes", Modifier.weight(1f)) { page = Page.GRADES }
                                    ServiceTile("🗓️", if (rtl) "الحضور" else "Présences", Modifier.weight(1f)) { page = Page.ATTENDANCE }
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    ServiceTile("✏️", if (rtl) "الواجبات" else "Devoirs", Modifier.weight(1f)) { page = Page.HOMEWORK }
                                    ServiceTile("🔔", if (rtl) "الإعلانات" else "Annonces", Modifier.weight(1f)) { page = Page.NEWS }
                                }
                                Spacer(Modifier.height(16.dp))
                                InfoCard("🔐", if (rtl) "حسابات بإدارة المدرسة" else "Accès par compte administré",
                                    if (rtl) "تنشئ الإدارة الحسابات وتوزع بيانات الدخول بشكل آمن." else "Les comptes doivent être créés par l’administration. La connexion réelle sera activée après mise en place du serveur sécurisé.")
                                Spacer(Modifier.height(12.dp))
                                InfoCard("☎️", if (rtl) "اتصلوا بالإدارة" else "Contacter l’administration",
                                    if (rtl) "الهاتف: 32914655\nالبريد الإلكتروني: dehabdellahi21@gmail.com" else "Téléphone : 32914655\nE-mail : dehabdellahi21@gmail.com")
                                Spacer(Modifier.height(8.dp))
                                Text(if (rtl) "دار البيضاء، الميناء، نواكشوط، موريتانيا" else "Dar El Baida, El Mina, Nouakchott, Mauritanie",
                                    color = Color(0xFF687989), fontSize = 12.sp)
                            }
                            Page.GRADES -> {
                                InfoCard("📊", if (rtl) "كشف النقاط" else "Relevé de notes",
                                    if (rtl) "ستظهر النتائج بعد تسجيل الدخول." else "Les résultats apparaîtront après connexion sécurisée.")
                                DemoRow(if (rtl) "الرياضيات" else "Mathématiques", "— / 20")
                                DemoRow(if (rtl) "اللغة الفرنسية" else "Français", "— / 20")
                                DemoRow(if (rtl) "اللغة العربية" else "Arabe", "— / 20")
                            }
                            Page.ATTENDANCE -> InfoCard("🗓️", if (rtl) "سجل الحضور" else "Suivi des présences",
                                if (rtl) "سجل الحضور غير متصل بعد بنظام المدرسة." else "Le registre des présences n’est pas encore relié au système de l’établissement.")
                            Page.HOMEWORK -> {
                                InfoCard("✏️", if (rtl) "الواجبات المنزلية" else "Travail à faire",
                                    if (rtl) "ستظهر الواجبات المنشورة من المعلمين هنا." else "Les devoirs publiés par les enseignants apparaîtront ici.")
                                DemoRow(if (rtl) "واجبات الأسبوع" else "Devoirs de la semaine", if (rtl) "قريباً" else "À venir")
                            }
                            Page.NEWS -> {
                                InfoCard("📣", if (rtl) "الأخبار والإعلانات" else "Actualités et annonces",
                                    if (rtl) "ستظهر الإعلانات الرسمية هنا." else "Les annonces officielles seront publiées ici.")
                                DemoRow(if (rtl) "إشعارات المدرسة" else "Notifications scolaires", if (rtl) "قريباً" else "À venir")
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            if (rtl) "نسخة تجريبية — لا تستخدم بيانات حقيقية" else "Version de démonstration — n’utilisez pas de données réelles",
                            color = Color(0xFF687989), fontSize = 11.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color(0xFF24445D), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(13.dp)) {
            Text(label, color = Color(0xFFD7E4EF), fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

@Composable
private fun InfoCard(emoji: String, title: String, body: String) {
    Surface(color = Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 1.dp) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.Top) {
            Text(emoji, fontSize = 24.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(5.dp))
                Text(body, color = Color(0xFF647586), fontSize = 13.sp, lineHeight = 19.sp)
            }
        }
    }
}

@Composable
private fun ServiceTile(emoji: String, title: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, color = Color.White, shape = RoundedCornerShape(17.dp), shadowElevation = 1.dp) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.Start) {
            Text(emoji, fontSize = 25.sp)
            Spacer(Modifier.height(10.dp))
            Text(title, color = Navy, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun DemoRow(label: String, value: String) {
    Surface(color = Color.White, shape = RoundedCornerShape(14.dp), modifier = Modifier.padding(top = 9.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, modifier = Modifier.weight(1f), color = Navy, fontSize = 14.sp)
            Text(value, color = Teal, fontWeight = FontWeight.Bold)
        }
    }
}
