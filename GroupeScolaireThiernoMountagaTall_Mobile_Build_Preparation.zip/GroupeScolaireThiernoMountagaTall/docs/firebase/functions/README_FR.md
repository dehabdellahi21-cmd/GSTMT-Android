# Fonction d'administration — modèle de procédure

La création des comptes doit passer par une Cloud Function protégée, utilisant le SDK Admin côté serveur. Ne jamais embarquer le SDK Admin, une clé de compte de service ou un secret dans l'application Android.

## Contrôles obligatoires avant implémentation
- Vérifier l'identité et le rôle ADMIN depuis des custom claims attribués dans un environnement de confiance.
- Valider les champs : rôle autorisé, identifiant scolaire unique, classe et coordonnées nécessaires.
- Limiter le débit et journaliser les actions d'administration sans écrire de mots de passe ou données sensibles dans les journaux.
- Créer l'utilisateur via Firebase Admin Authentication et définir les claims côté serveur.
- Prévoir désactivation/réactivation, réinitialisation de mot de passe, départ d'un élève, transfert de classe et révocation de sessions.
- Ne jamais permettre à un utilisateur de choisir son propre rôle depuis le client.
- Protéger les données parent-enfant avec une relation vérifiée côté serveur/règles.
- Tester les appels autorisés et refusés avec Firebase Emulator Suite.

Ce répertoire est une spécification, pas une fonction déployable. Il manque le projet Firebase réel, la région, la méthode de connexion confirmée et les règles métier de l'établissement.
